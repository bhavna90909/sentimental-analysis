const hinglish = {
    labels: {
        'stupide': -2
    }
}

module.exports = hinglish;