module.exports = {
    mongoURL: 'mongodb://localhost/analysis'
}